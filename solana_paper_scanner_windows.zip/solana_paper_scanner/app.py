import streamlit as st
import pandas as pd
from datetime import datetime, timezone
from scanner.engine import Scanner
from scanner.storage import init_db, recent_events, recent_candidates, portfolio_summary, recent_trades

st.set_page_config(page_title="Solana Paper Scanner", page_icon="◎", layout="wide")
init_db()
st.title("◎ Solana Alpha Scanner")
st.caption("Шест агента · Само paper trading · Без портфейл и без реални трансакции")

with st.sidebar:
    st.header("Настройки")
    rpc_url = st.text_input("Solana RPC URL", value="https://api.mainnet-beta.solana.com")
    refresh = st.slider("Интервал на сканиране (сек.)", 30, 300, 60, 15)
    paper_balance = st.number_input("Виртуален баланс ($)", min_value=100.0, value=1000.0, step=100.0)
    max_allocation = st.slider("Макс. виртуална позиция (%)", 1, 8, 8)
    run_once = st.button("Сканирай сега", type="primary")
    st.caption("За непрекъсната работа остави приложението стартирано на компютъра.")

scanner = Scanner(rpc_url=rpc_url, paper_balance=paper_balance,
                  max_allocation_pct=max_allocation, stop_pct=6.0, trail_activation_pct=12.0)

if run_once:
    with st.spinner("Шестте агента проверяват новите двойки..."):
        result = scanner.run_cycle()
    st.success(f"Сканирането приключи. Намерени: {result['seen']} · Отхвърлени: {result['killed']} · Одобрени: {result['passed']}")

summary = portfolio_summary()
c1,c2,c3,c4 = st.columns(4)
c1.metric("Виртуален баланс", f"${summary['equity']:,.2f}")
c2.metric("Отворени позиции", summary["open_positions"])
c3.metric("Затворени paper сделки", summary["closed_trades"])
c4.metric("Последно сканиране", summary["last_scan"] or "—")

tabs = st.tabs(["Кандидати", "Paper позиции", "Журнал на агентите", "Как работи"])
with tabs[0]:
    st.subheader("Кандидати, преминали оценката")
    df = pd.DataFrame(recent_candidates(100))
    if not df.empty:
        st.dataframe(df, use_container_width=True, hide_index=True)
    else:
        st.info("Все още няма кандидати. Натисни „Сканирай сега“.")
with tabs[1]:
    st.subheader("Симулирани сделки")
    trades = pd.DataFrame(recent_trades(100))
    if not trades.empty:
        st.dataframe(trades, use_container_width=True, hide_index=True)
    else:
        st.info("Няма paper сделки.")
with tabs[2]:
    st.subheader("Всички решения — включително отхвърлянията")
    events = pd.DataFrame(recent_events(300))
    if not events.empty:
        st.dataframe(events, use_container_width=True, hide_index=True)
    else:
        st.info("Журналът е празен.")
with tabs[3]:
    st.markdown("""
**Scout → Filter → Analyst → Executor → Risk → Logger**

- **Scout:** DexScreener двойки на възраст 30 мин.–72 ч. и пазарна капитализация $300K–$20M.
- **Filter:** твърди проверки за mint/freeze authority, ликвидност, обем, концентрация, dev дял, bundled launch и рязък ръст.
- **Analyst:** оценка 0–100; минимум 70.
- **Executor:** само виртуални позиции до зададения процент от виртуалния баланс.
- **Risk:** симулиран стоп −6%; trailing защита след +12%.
- **Logger:** записва всяко решение в локална SQLite база.

**Важно:** публичният DexScreener API не предоставя всички on-chain проверки. Ако дадена проверка липсва или не може да бъде потвърдена, токенът се отхвърля. Това е предпазлив режим, не гаранция за безопасност.
""")

st.caption(f"Последно обновяване на таблото: {datetime.now().astimezone().strftime('%Y-%m-%d %H:%M:%S %Z')}")
