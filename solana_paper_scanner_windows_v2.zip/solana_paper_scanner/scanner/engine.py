from datetime import datetime, timezone
from .data import fetch_pairs, pair_metrics
from .onchain import mint_authorities, largest_accounts, supply
from .storage import log_event, add_candidate, set_state, get_state, conn
import json

class Scanner:
    def __init__(self,rpc_url,paper_balance=1000,max_allocation_pct=8,stop_pct=6,trail_activation_pct=12):
        self.rpc_url=rpc_url
        self.max_allocation_pct=max_allocation_pct
        self.stop_pct=stop_pct
        self.trail_activation_pct=trail_activation_pct
        self.paper_balance=float(paper_balance)

    def event(self,agent,m,decision,reason,score=None,details=None):
        log_event(agent,m.get("mint",""),m.get("symbol",""),decision,reason,score,details)

    def filter_pair(self,m):
        hard=[]
        if not (0.5 <= m["age_h"] <= 72): hard.append("Възраст извън 30 мин.–72 ч.")
        if not (300_000 <= m["market_cap"] <= 20_000_000): hard.append("Пазарна капитализация извън диапазона")
        if m["liquidity"] < 40_000: hard.append("Ликвидност под $40K")
        if m["volume_1h"] < 50_000: hard.append("Обем за 1 ч. под $50K")
        if m["price_change_1h"] >= 80: hard.append("Вече е нараснал с поне 80% за 1 ч.")
        try:
            mint_ok,freeze_ok=mint_authorities(self.rpc_url,m["mint"])
            if not mint_ok: hard.append("Mint authority не е отнета")
            if not freeze_ok: hard.append("Freeze authority не е отнета")
        except Exception as e:
            hard.append("Mint/freeze проверката е неуспешна: "+str(e)[:100])
        try:
            largest=largest_accounts(self.rpc_url,m["mint"])
            total=supply(self.rpc_url,m["mint"])
            if total <= 0: raise RuntimeError("Невалидно общо предлагане")
            top10=sum(float(a.get("uiAmount") or 0) for a in largest[:10])/total*100
            if top10 > 25: hard.append(f"Топ 10 държат {top10:.1f}%")
        except Exception as e:
            top10=None
            hard.append("Проверката за концентрация е неуспешна: "+str(e)[:100])
        # These signals are not supplied reliably by DexScreener/RPC alone.
        # Conservative fail-closed until an indexed, independently verified source is connected.
        hard += ["LP lock/burn не е потвърден от интегриран verifier",
                 "Dev дял/история на rug не е потвърдена",
                 "Bundled launch процент не е потвърден"]
        return hard, {"top10_pct":top10}

    def score(self,m,extra):
        # Provisional score from observable market activity only.
        momentum=min(20,max(0,(m["price_change_1h"]+10)/4))
        buyers=min(15,m["buyers_1h"]/10)
        ratio=min(15,max(0,m["ratio"]*5))
        liqmc=min(10,(m["liquidity"]/max(m["market_cap"],1))*100)
        holder_growth=0   # no holder-time series available yet
        smart_wallets=0  # no labelled-wallet dataset connected
        total=momentum+buyers+ratio+liqmc+holder_growth+smart_wallets
        return round(total,1),{"momentum":round(momentum,1),"unique_buyers_proxy":round(buyers,1),
          "buy_sell_ratio":round(ratio,1),"holder_growth":holder_growth,
          "liquidity_mcap":round(liqmc,1),"smart_wallets":smart_wallets,
          "note":"Броят покупки не е брой уникални купувачи; holder growth и smart-wallet оценката са 0 без исторически индекс."}

    def open_paper(self,m):
        with conn() as c:
            cash=float(c.execute("SELECT value FROM state WHERE key='virtual_cash'").fetchone()[0])
            allocation=min(cash,self.paper_balance*self.max_allocation_pct/100)
            if allocation <= 0 or m["price"] <= 0: return
            qty=allocation/m["price"]
            c.execute("UPDATE state SET value=? WHERE key='virtual_cash'",(str(cash-allocation),))
            c.execute("""INSERT INTO trades(opened_at,mint,symbol,entry,current,quantity,allocation,status,pnl_pct,high_water)
              VALUES(?,?,?,?,?,?,?,?,?,?)""",(datetime.now(timezone.utc).isoformat(),m["mint"],m["symbol"],
              m["price"],m["price"],qty,allocation,"OPEN",0,m["price"]))
        self.event("Executor",m,"PAPER_OPEN","Виртуална позиция; без реална трансакция",details={"allocation":allocation})

    def update_positions(self):
        # Current prices are refreshed from DexScreener search result set; missing pairs remain unchanged.
        prices={x.get("baseToken",{}).get("address"):float(x.get("priceUsd") or 0) for x in fetch_pairs()}
        with conn() as c:
            rows=c.execute("SELECT * FROM trades WHERE status='OPEN'").fetchall()
            for t in rows:
                px=prices.get(t["mint"],0)
                if px <= 0: continue
                high=max(float(t["high_water"]),px)
                pnl=(px/float(t["entry"])-1)*100
                exit_reason=None
                if pnl <= -self.stop_pct: exit_reason="STOP_LOSS"
                elif pnl >= self.trail_activation_pct and px <= high*0.94: exit_reason="TRAILING_STOP"
                if exit_reason:
                    proceeds=float(t["quantity"])*px
                    cash=float(c.execute("SELECT value FROM state WHERE key='virtual_cash'").fetchone()[0])
                    c.execute("UPDATE state SET value=? WHERE key='virtual_cash'",(str(cash+proceeds),))
                    c.execute("UPDATE trades SET current=?,closed_at=?,status='CLOSED',pnl_pct=?,exit_reason=?,high_water=? WHERE id=?",
                      (px,datetime.now(timezone.utc).isoformat(),pnl,exit_reason,high,t["id"]))
                    log_event("Risk",t["mint"],t["symbol"],"PAPER_CLOSE",exit_reason,pnl,{"price":px})
                else:
                    c.execute("UPDATE trades SET current=?,pnl_pct=?,high_water=? WHERE id=?",(px,pnl,high,t["id"]))

    def run_cycle(self):
        pairs=fetch_pairs(); seen=0;killed=0;passed=0
        self.update_positions()
        with conn() as c:
            existing={r["mint"] for r in c.execute("SELECT mint FROM trades WHERE status='OPEN'")}
        for p in pairs:
            m=pair_metrics(p)
            if not m["mint"] or m["mint"] in existing: continue
            if not (0.5 <= m["age_h"] <= 72 and 300_000 <= m["market_cap"] <= 20_000_000): continue
            seen+=1
            self.event("Scout",m,"FOUND","Покрива базовия диапазон",details={"age_h":m["age_h"],"mcap":m["market_cap"]})
            fails,extra=self.filter_pair(m)
            if fails:
                killed+=1
                self.event("Filter",m,"KILL","; ".join(fails),details=extra)
                continue
            self.event("Filter",m,"PASS","Всички налични hard checks преминати",details=extra)
            score,signals=self.score(m,extra)
            self.event("Analyst",m,"SCORED",f"Оценка {score}/100",score,signals)
            if score < 70:
                killed+=1; self.event("Analyst",m,"KILL","Под минималния праг 70",score,signals); continue
            add_candidate({**m,"score":score,"signals":signals})
            passed+=1
            self.open_paper(m)
        set_state("last_scan",datetime.now().astimezone().strftime("%Y-%m-%d %H:%M:%S"))
        return {"seen":seen,"killed":killed,"passed":passed}
