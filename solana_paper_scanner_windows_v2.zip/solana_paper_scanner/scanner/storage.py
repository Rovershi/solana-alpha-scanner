import sqlite3, json
from pathlib import Path
from datetime import datetime, timezone

DB = Path(__file__).resolve().parent.parent / "scanner.db"

def conn():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    return c

def init_db():
    with conn() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS events(
          id INTEGER PRIMARY KEY, ts TEXT, agent TEXT, mint TEXT, symbol TEXT,
          decision TEXT, reason TEXT, score REAL, details TEXT);
        CREATE TABLE IF NOT EXISTS candidates(
          id INTEGER PRIMARY KEY, ts TEXT, mint TEXT, symbol TEXT, name TEXT,
          score REAL, market_cap REAL, liquidity REAL, volume_1h REAL,
          price_change_1h REAL, buyers_1h INTEGER, ratio REAL, reasons TEXT);
        CREATE TABLE IF NOT EXISTS trades(
          id INTEGER PRIMARY KEY, opened_at TEXT, closed_at TEXT, mint TEXT,
          symbol TEXT, entry REAL, current REAL, quantity REAL, allocation REAL,
          status TEXT, pnl_pct REAL, exit_reason TEXT, high_water REAL);
        CREATE TABLE IF NOT EXISTS state(key TEXT PRIMARY KEY, value TEXT);
        """)
        c.execute("INSERT OR IGNORE INTO state(key,value) VALUES('virtual_cash','1000')")
        c.execute("INSERT OR IGNORE INTO state(key,value) VALUES('last_scan','')")

def log_event(agent, mint, symbol, decision, reason, score=None, details=None):
    with conn() as c:
        c.execute("INSERT INTO events(ts,agent,mint,symbol,decision,reason,score,details) VALUES(?,?,?,?,?,?,?,?)",
                  (datetime.now(timezone.utc).isoformat(),agent,mint,symbol,decision,reason,score,json.dumps(details or {})))

def add_candidate(x):
    with conn() as c:
        c.execute("""INSERT INTO candidates(ts,mint,symbol,name,score,market_cap,liquidity,volume_1h,
        price_change_1h,buyers_1h,ratio,reasons) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",
        (datetime.now(timezone.utc).isoformat(),x["mint"],x["symbol"],x["name"],x["score"],
         x["market_cap"],x["liquidity"],x["volume_1h"],x["price_change_1h"],x["buyers_1h"],
         x["ratio"],json.dumps(x["signals"])))

def set_state(k,v):
    with conn() as c: c.execute("INSERT OR REPLACE INTO state(key,value) VALUES(?,?)",(k,str(v)))

def get_state(k,default=None):
    with conn() as c:
        r=c.execute("SELECT value FROM state WHERE key=?",(k,)).fetchone()
        return r["value"] if r else default

def recent_events(n=200):
    with conn() as c: return [dict(r) for r in c.execute("SELECT * FROM events ORDER BY id DESC LIMIT ?",(n,))]
def recent_candidates(n=100):
    with conn() as c: return [dict(r) for r in c.execute("SELECT * FROM candidates ORDER BY id DESC LIMIT ?",(n,))]
def recent_trades(n=100):
    with conn() as c: return [dict(r) for r in c.execute("SELECT * FROM trades ORDER BY id DESC LIMIT ?",(n,))]
def portfolio_summary():
    with conn() as c:
        cash=float(c.execute("SELECT value FROM state WHERE key='virtual_cash'").fetchone()[0])
        opened=c.execute("SELECT COUNT(*) n FROM trades WHERE status='OPEN'").fetchone()["n"]
        closed=c.execute("SELECT COUNT(*) n FROM trades WHERE status='CLOSED'").fetchone()["n"]
        last=get_state("last_scan","")
        return {"equity":cash,"open_positions":opened,"closed_trades":closed,"last_scan":last}
