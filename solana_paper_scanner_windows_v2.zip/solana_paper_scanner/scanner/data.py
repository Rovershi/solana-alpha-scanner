import requests, time
from datetime import datetime, timezone

DEX_SEARCH = "https://api.dexscreener.com/latest/dex/search"

def fetch_pairs():
    # DexScreener search endpoint returns current matching pairs; search broad Solana terms.
    # Deduplication is performed by pair address. API limits/rate limits may apply.
    queries = ["SOL", "pump", "USDC"]
    found = {}
    for q in queries:
        try:
            r=requests.get(DEX_SEARCH,params={"q":q},timeout=15)
            r.raise_for_status()
            for p in (r.json().get("pairs") or []):
                if p.get("chainId")=="solana" and p.get("pairAddress"):
                    found[p["pairAddress"]]=p
            time.sleep(0.25)
        except requests.RequestException:
            continue
    return list(found.values())

def num(v, default=0.0):
    try: return float(v or 0)
    except (TypeError,ValueError): return default

def pair_metrics(p):
    base=p.get("baseToken") or {}
    created=num(p.get("pairCreatedAt"))
    age_h=(datetime.now(timezone.utc).timestamp()*1000-created)/3600000 if created else 1e9
    tx=(p.get("txns") or {}).get("h1") or {}
    buys=int(num(tx.get("buys"))); sells=int(num(tx.get("sells")))
    vol=(p.get("volume") or {})
    liq=(p.get("liquidity") or {})
    pc=(p.get("priceChange") or {})
    return {
      "mint":base.get("address",""), "symbol":base.get("symbol","?"),
      "name":base.get("name","?"), "pair":p.get("pairAddress",""),
      "url":p.get("url",""), "age_h":age_h,
      "market_cap":num(p.get("marketCap") or p.get("fdv")),
      "liquidity":num(liq.get("usd")), "volume_1h":num(vol.get("h1")),
      "price_change_1h":num(pc.get("h1")), "buys":buys, "sells":sells,
      "buyers_1h":buys, "ratio":buys/max(sells,1),
      "price":num(p.get("priceUsd")), "raw":p
    }
