import requests

def rpc(rpc_url, method, params):
    r=requests.post(rpc_url,json={"jsonrpc":"2.0","id":1,"method":method,"params":params},timeout=15)
    r.raise_for_status()
    data=r.json()
    if data.get("error"): raise RuntimeError(data["error"])
    return data.get("result")

def mint_authorities(rpc_url,mint):
    # Parsed SPL mint account; unknown parsing is a hard failure.
    result=rpc(rpc_url,"getAccountInfo",[mint,{"encoding":"jsonParsed","commitment":"confirmed"}])
    value=(result or {}).get("value")
    if not value: raise RuntimeError("Mint account not found")
    info=value.get("data",{}).get("parsed",{}).get("info",{})
    if not info: raise RuntimeError("Mint account could not be parsed")
    return info.get("mintAuthority") is None, info.get("freezeAuthority") is None

def largest_accounts(rpc_url,mint):
    result=rpc(rpc_url,"getTokenLargestAccounts",[mint,{"commitment":"confirmed"}])
    return (result or {}).get("value",[])

def supply(rpc_url,mint):
    result=rpc(rpc_url,"getTokenSupply",[mint,{"commitment":"confirmed"}])
    val=(result or {}).get("value") or {}
    amount=float(val.get("uiAmount") or 0)
    return amount
